"""JEE Paper Studio - polished GUI with in-app paper and answer previews."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os, shutil, datetime, subprocess, sys
import jee_qpms as core

BG = '#0b1220'; PANEL = '#111c2e'; PANEL2 = '#17243a'; TEXT = '#e6edf7'; MUTED = '#91a4bd'; BLUE = '#3b82f6'; GREEN = '#22c55e'; RED = '#ef4444'; GOLD='#f59e0b'
HISTORY_DIR='paper_history'

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('JEE Paper Studio')
        self.geometry('1180x760'); self.minsize(1000,680); self.configure(bg=BG)
        core.ensure_files(); self.rows=core.load_questions(); os.makedirs(HISTORY_DIR,exist_ok=True)
        self._style(); self._layout(); self.refresh()

    def _style(self):
        s=ttk.Style(self); s.theme_use('clam')
        s.configure('Treeview',background=PANEL,foreground=TEXT,fieldbackground=PANEL,rowheight=30,borderwidth=0)
        s.configure('Treeview.Heading',background=PANEL2,foreground=TEXT,font=('Segoe UI',10,'bold'),relief='flat')
        s.map('Treeview',background=[('selected',BLUE)],foreground=[('selected','white')])
        s.configure('TCombobox',fieldbackground=PANEL2,background=PANEL2,foreground=TEXT)

    def _layout(self):
        header=tk.Frame(self,bg=BG); header.pack(fill='x',padx=24,pady=(18,10))
        tk.Label(header,text='🎓  JEE PAPER STUDIO',font=('Segoe UI',22,'bold'),bg=BG,fg=TEXT).pack(anchor='w')
        tk.Label(header,text='Question Bank  •  Paper Generator  •  Paper Preview  •  Reports',font=('Segoe UI',10),bg=BG,fg=MUTED).pack(anchor='w',pady=(3,0))
        self.nav=tk.Frame(self,bg=BG); self.nav.pack(fill='x',padx=24,pady=5)
        self.content=tk.Frame(self,bg=BG); self.content.pack(fill='both',expand=True,padx=24,pady=(8,20)); self.show_dashboard()

    def clear_content(self):
        for w in self.content.winfo_children(): w.destroy()

    def button(self,parent,text,command,color=BLUE):
        return tk.Button(parent,text=text,command=command,bg=color,fg='white',activebackground=color,activeforeground='white',relief='flat',font=('Segoe UI',10,'bold'),padx=14,pady=9,cursor='hand2')

    def navbuttons(self):
        for w in self.nav.winfo_children(): w.destroy()
        for name,fn in [('Dashboard',self.show_dashboard),('Question Bank',self.show_bank),('Generate Paper',self.show_generate),('Recent Papers',self.show_recent)]:
            self.button(self.nav,name,fn,PANEL2).pack(side='left',padx=(0,8))

    def card(self,parent,label,value):
        f=tk.Frame(parent,bg=PANEL,padx=18,pady=15); f.pack(side='left',fill='x',expand=True,padx=6)
        tk.Label(f,text=label,bg=PANEL,fg=MUTED,font=('Segoe UI',10)).pack(anchor='w')
        tk.Label(f,text=str(value),bg=PANEL,fg=TEXT,font=('Segoe UI',24,'bold')).pack(anchor='w',pady=(5,0))

    def refresh(self): self.rows=core.load_questions()

    def show_dashboard(self):
        self.navbuttons(); self.clear_content(); self.refresh()
        tk.Label(self.content,text='Dashboard',bg=BG,fg=TEXT,font=('Segoe UI',20,'bold')).pack(anchor='w',pady=(0,14))
        top=tk.Frame(self.content,bg=BG); top.pack(fill='x')
        self.card(top,'TOTAL QUESTIONS',len(self.rows)); self.card(top,'PHYSICS',sum(r.get('subject')=='Physics' for r in self.rows)); self.card(top,'CHEMISTRY',sum(r.get('subject')=='Chemistry' for r in self.rows)); self.card(top,'MATHEMATICS',sum(r.get('subject')=='Mathematics' for r in self.rows))
        lower=tk.Frame(self.content,bg=PANEL,padx=20,pady=20); lower.pack(fill='x',pady=18)
        tk.Label(lower,text='Quick Actions',bg=PANEL,fg=TEXT,font=('Segoe UI',14,'bold')).pack(anchor='w')
        actions=tk.Frame(lower,bg=PANEL); actions.pack(anchor='w',pady=12)
        self.button(actions,'＋  Add Question',self.show_bank).pack(side='left',padx=(0,8)); self.button(actions,'⚡  Generate Paper',self.show_generate,GREEN).pack(side='left',padx=(0,8)); self.button(actions,'▤  Recent Papers',self.show_recent,GOLD).pack(side='left',padx=(0,8)); self.button(actions,'↻  Reset Usage History',self.reset_history,RED).pack(side='left')
        tk.Label(self.content,text='Recent Question Bank Preview',bg=BG,fg=MUTED,font=('Segoe UI',11,'bold')).pack(anchor='w')
        preview=tk.Frame(self.content,bg=PANEL); preview.pack(fill='both',expand=True,pady=8)
        cols=('id','subject','chapter','difficulty','type'); tree=ttk.Treeview(preview,columns=cols,show='headings',height=6)
        for c,w in zip(cols,[90,140,220,120,110]): tree.heading(c,text=c.title()); tree.column(c,width=w)
        for r in self.rows[:8]: tree.insert('', 'end',values=(r.get('id'),r.get('subject'),r.get('chapter'),r.get('difficulty'),r.get('type')))
        tree.pack(fill='both',expand=True,padx=10,pady=10)

    def show_bank(self):
        self.navbuttons(); self.clear_content(); self.refresh()
        tk.Label(self.content,text='Question Bank',bg=BG,fg=TEXT,font=('Segoe UI',20,'bold')).pack(anchor='w')
        form=tk.Frame(self.content,bg=PANEL,padx=16,pady=14); form.pack(fill='x',pady=12)
        self.vars={k:tk.StringVar() for k in ['subject','chapter','type','difficulty','marks','question','options','answer']}
        fields=[('Subject','subject',core.SUBJECTS),('Chapter','chapter',None),('Type','type',['MCQ','Numerical']),('Difficulty','difficulty',core.DIFFICULTIES),('Marks','marks',None),('Question','question',None),('Options (comma-separated)','options',None),('Correct Answer','answer',None)]
        for i,(label,key,choices) in enumerate(fields):
            row=i//4; col=(i%4)*2; tk.Label(form,text=label,bg=PANEL,fg=MUTED,font=('Segoe UI',9)).grid(row=row*2,column=col,sticky='w',padx=5,pady=(3,0))
            widget=ttk.Combobox(form,textvariable=self.vars[key],values=choices,state='readonly',width=20) if choices else tk.Entry(form,textvariable=self.vars[key],bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief='flat',width=23)
            widget.grid(row=row*2+1,column=col,columnspan=2,sticky='ew',padx=5,pady=4)
        for col in range(8): form.grid_columnconfigure(col,weight=1)
        btns=tk.Frame(form,bg=PANEL); btns.grid(row=4,column=0,columnspan=8,sticky='w',pady=(10,0))
        self.button(btns,'Add Question',self.add_question,GREEN).pack(side='left',padx=(0,8)); self.button(btns,'Update Selected',self.update_question).pack(side='left',padx=(0,8)); self.button(btns,'Delete Selected',self.delete_question,RED).pack(side='left',padx=(0,8)); self.button(btns,'Clear Form',self.clear_form,PANEL2).pack(side='left')
        tableframe=tk.Frame(self.content,bg=PANEL); tableframe.pack(fill='both',expand=True); cols=('id','subject','chapter','type','difficulty','marks','question','answer'); self.tree=ttk.Treeview(tableframe,columns=cols,show='headings')
        widths=[70,110,130,90,90,65,380,100]
        for c,w in zip(cols,widths): self.tree.heading(c,text=c.title()); self.tree.column(c,width=w,stretch=(c=='question'))
        vs=ttk.Scrollbar(tableframe,orient='vertical',command=self.tree.yview); self.tree.configure(yscrollcommand=vs.set); self.tree.pack(side='left',fill='both',expand=True); vs.pack(side='right',fill='y'); self.tree.bind('<<TreeviewSelect>>',self.select_row); self.populate_table()

    def populate_table(self):
        for x in self.tree.get_children(): self.tree.delete(x)
        for r in self.rows: self.tree.insert('', 'end',values=tuple(r.get(k,'') for k in ('id','subject','chapter','type','difficulty','marks','question','answer')))
    def clear_form(self):
        for v in self.vars.values(): v.set('')
    def get_form(self): return {k:v.get().strip() for k,v in self.vars.items()}
    def add_question(self):
        self.rows=core.add_question(self.rows,self.get_form()); self.populate_table(); self.clear_form(); self.show_status('Question added (if validation passed).')
    def select_row(self,event=None):
        sel=self.tree.selection()
        if not sel:return
        qid=self.tree.item(sel[0])['values'][0]; r=next((x for x in self.rows if x['id']==qid),None)
        if r:
            for k in self.vars:self.vars[k].set(r.get(k,''))
    def update_question(self):
        sel=self.tree.selection()
        if not sel:messagebox.showinfo('Select question','Select a question in the table first.');return
        qid=self.tree.item(sel[0])['values'][0];q=self.get_form()
        for r in self.rows:
            if r['id']==qid:
                for k,v in q.items():
                    if v:r[k]=v
                core.save_questions(self.rows);self.refresh();self.populate_table();messagebox.showinfo('Updated','Question updated.');return
    def delete_question(self):
        sel=self.tree.selection()
        if not sel:messagebox.showinfo('Select question','Select a question first.');return
        qid=self.tree.item(sel[0])['values'][0]
        if messagebox.askyesno('Confirm deletion',f'Delete {qid}?'):
            self.rows=[r for r in self.rows if r['id']!=qid];core.save_questions(self.rows);self.populate_table();self.clear_form()

    def show_generate(self):
        self.navbuttons(); self.clear_content(); tk.Label(self.content,text='Paper Generator',bg=BG,fg=TEXT,font=('Segoe UI',20,'bold')).pack(anchor='w',pady=(0,12))
        panel=tk.Frame(self.content,bg=PANEL,padx=22,pady=22);panel.pack(fill='x');tk.Label(panel,text='Create a fresh practice paper',bg=PANEL,fg=TEXT,font=('Segoe UI',14,'bold')).pack(anchor='w')
        tk.Label(panel,text='Generate a 15-question paper. Your generated paper and answer key open in an in-app preview window.',bg=PANEL,fg=MUTED,wraplength=800).pack(anchor='w',pady=10)
        self.button(panel,'Generate 15-Question Paper',self.generate,GREEN).pack(anchor='w',pady=8)
        files=tk.Frame(self.content,bg=PANEL,padx=20,pady=20);files.pack(fill='x',pady=16);tk.Label(files,text='Output files',bg=PANEL,fg=TEXT,font=('Segoe UI',13,'bold')).pack(anchor='w')
        for f in ['outputs/generated_paper.txt','outputs/answer_key.txt','outputs/paper_summary.txt']:tk.Label(files,text='•  '+f,bg=PANEL,fg=MUTED,font=('Segoe UI',10)).pack(anchor='w',pady=3)
        self.status=tk.Label(self.content,text='',bg=BG,fg=GREEN,font=('Segoe UI',10));self.status.pack(anchor='w',pady=8)

    def generate(self):
        self.refresh(); used=core.read_used()
        if len([r for r in self.rows if r['id'] not in used])<15:
            if not messagebox.askyesno('Not enough unused questions','There may not be enough unused questions. Clear history and try again?'):return
            core.clear_history()
        try:
            core.generate_paper(self.rows,15); self.snapshot_generated(); self.open_preview(os.path.join('outputs','generated_paper.txt'),os.path.join('outputs','answer_key.txt'),os.path.join('outputs','paper_summary.txt'))
        except Exception as e:messagebox.showerror('Generation error',str(e))

    def snapshot_generated(self):
        os.makedirs(HISTORY_DIR,exist_ok=True); stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S'); folder=os.path.join(HISTORY_DIR,stamp);os.makedirs(folder,exist_ok=True)
        for name in ['generated_paper.txt','answer_key.txt','paper_summary.txt']:
            src=os.path.join('outputs',name)
            if os.path.exists(src):shutil.copy2(src,os.path.join(folder,name))

    def open_preview(self,paper_path,key_path,summary_path=None):
        if not os.path.exists(paper_path):messagebox.showerror('Missing paper','Paper file was not found.');return
        win=tk.Toplevel(self);win.title('Paper Preview — JEE Paper Studio');win.geometry('900x720');win.configure(bg=BG);win.transient(self)
        top=tk.Frame(win,bg=PANEL,padx=18,pady=14);top.pack(fill='x',padx=14,pady=14)
        tk.Label(top,text='📄  PRACTICE PAPER PREVIEW',bg=PANEL,fg=TEXT,font=('Segoe UI',16,'bold')).pack(anchor='w')
        tk.Label(top,text=os.path.basename(os.path.dirname(paper_path))+'  •  Review, save or print your paper',bg=PANEL,fg=MUTED,font=('Segoe UI',9)).pack(anchor='w',pady=(4,0))
        body=tk.Frame(win,bg=PANEL);body.pack(fill='both',expand=True,padx=14,pady=(0,12));text=tk.Text(body,bg='#f8fafc',fg='#111827',font=('Segoe UI',11),wrap='word',padx=24,pady=20,relief='flat')
        scroll=ttk.Scrollbar(body,command=text.yview);text.configure(yscrollcommand=scroll.set);text.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        with open(paper_path,encoding='utf-8') as f:text.insert('1.0',f.read())
        text.configure(state='disabled')
        bar=tk.Frame(win,bg=BG);bar.pack(fill='x',padx=14,pady=(0,14))
        self.button(bar,'Save Paper As…',lambda:self.save_as(paper_path,'paper'),BLUE).pack(side='left',padx=(0,8))
        self.button(bar,'View Answer Key',lambda:self.open_text_popup('Answer Key',key_path),GOLD).pack(side='left',padx=(0,8))
        self.button(bar,'View Summary',lambda:self.open_text_popup('Paper Summary',summary_path),PANEL2).pack(side='left',padx=(0,8)) if summary_path and os.path.exists(summary_path) else None
        self.button(bar,'Export PDF',lambda:self.export_pdf(paper_path),GREEN).pack(side='left',padx=(0,8))
        self.button(bar,'Print',lambda:self.print_file(paper_path),PANEL2).pack(side='left',padx=(0,8));self.button(bar,'Close',win.destroy,RED).pack(side='right')

    def open_text_popup(self,title,path):
        if not path or not os.path.exists(path):messagebox.showerror('Missing file','Requested file was not found.');return
        win=tk.Toplevel(self);win.title(title+' — JEE Paper Studio');win.geometry('720x620');win.configure(bg=BG)
        tk.Label(win,text=title.upper(),bg=PANEL,fg=TEXT,font=('Segoe UI',16,'bold'),padx=15,pady=12).pack(fill='x',padx=12,pady=12)
        frame=tk.Frame(win,bg=PANEL);frame.pack(fill='both',expand=True,padx=12,pady=(0,12));t=tk.Text(frame,bg='#f8fafc',fg='#111827',font=('Segoe UI',11),wrap='word',padx=20,pady=20)
        sb=ttk.Scrollbar(frame,command=t.yview);t.configure(yscrollcommand=sb.set);t.pack(side='left',fill='both',expand=True);sb.pack(side='right',fill='y')
        with open(path,encoding='utf-8') as f:t.insert('1.0',f.read())
        t.configure(state='disabled');self.button(win,'Close',win.destroy,RED).pack(pady=12)

    def save_as(self,path,kind):
        target=filedialog.asksaveasfilename(title='Save '+kind,defaultextension='.txt',filetypes=[('Text file','*.txt'),('All files','*.*')])
        if target:
            shutil.copy2(path,target);messagebox.showinfo('Saved','File saved successfully.')

    def export_pdf(self,paper_path):
        target=filedialog.asksaveasfilename(title='Export paper to PDF',defaultextension='.pdf',filetypes=[('PDF','*.pdf')])
        if not target:return
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            doc=SimpleDocTemplate(target,pagesize=A4);styles=getSampleStyleSheet();story=[]
            with open(paper_path,encoding='utf-8') as f:content=f.read()
            for line in content.splitlines():story.append(Paragraph(line.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;') or '&nbsp;',styles['Normal']));story.append(Spacer(1,4))
            doc.build(story);messagebox.showinfo('PDF Export','PDF exported successfully.')
        except ImportError:messagebox.showerror('PDF library unavailable','PDF export needs reportlab. Install it using: pip install reportlab')
        except Exception as e:messagebox.showerror('PDF export error',str(e))

    def print_file(self,path):
        try:
            if sys.platform=='win32':os.startfile(os.path.abspath(path),'print')
            elif sys.platform=='darwin':subprocess.Popen(['open',path])
            else:subprocess.Popen(['xdg-open',path])
            messagebox.showinfo('Print','The file was sent to your system print handler or opened for printing.')
        except Exception as e:messagebox.showerror('Print error',str(e))

    def show_recent(self):
        self.navbuttons();self.clear_content();tk.Label(self.content,text='Recent Papers',bg=BG,fg=TEXT,font=('Segoe UI',20,'bold')).pack(anchor='w',pady=(0,12))
        frame=tk.Frame(self.content,bg=PANEL);frame.pack(fill='both',expand=True)
        cols=('generated','paper','key','summary');tree=ttk.Treeview(frame,columns=cols,show='headings')
        for c,w in zip(cols,[190,240,240,240]):tree.heading(c,text=c.title());tree.column(c,width=w)
        sb=ttk.Scrollbar(frame,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=sb.set);tree.pack(side='left',fill='both',expand=True,padx=8,pady=8);sb.pack(side='right',fill='y')
        folders=sorted([f for f in os.listdir(HISTORY_DIR) if os.path.isdir(os.path.join(HISTORY_DIR,f))],reverse=True) if os.path.exists(HISTORY_DIR) else []
        for folder in folders:
            path=os.path.join(HISTORY_DIR,folder);p=os.path.join(path,'generated_paper.txt');k=os.path.join(path,'answer_key.txt');s=os.path.join(path,'paper_summary.txt')
            if os.path.exists(p):tree.insert('', 'end',iid=folder,values=(folder,p,k,s))
        actions=tk.Frame(self.content,bg=BG);actions.pack(fill='x',pady=12)
        def open_selected():
            sel=tree.selection()
            if not sel:messagebox.showinfo('Select paper','Select a paper row first.');return
            vals=tree.item(sel[0])['values'];self.open_preview(vals[1],vals[2],vals[3])
        self.button(actions,'Open Selected Paper',open_selected,GREEN).pack(side='left',padx=(0,8));self.button(actions,'Refresh',self.show_recent,PANEL2).pack(side='left')

    def reset_history(self):
        if messagebox.askyesno('Reset history','Clear previously used question IDs?'):
            core.clear_history();messagebox.showinfo('Done','Usage history cleared.')
    def show_status(self,msg):messagebox.showinfo('JEE Paper Studio',msg)

if __name__=='__main__':App().mainloop()

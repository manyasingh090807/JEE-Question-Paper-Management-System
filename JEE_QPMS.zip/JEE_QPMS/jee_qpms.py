"""JEE Question Paper Management System - menu-driven CSV project."""
import csv, os, random
from datetime import datetime

DATA_FILE = 'questions.csv'
HISTORY_FILE = 'used_questions.txt'
PAPER_FILE = 'outputs/generated_paper.txt'
KEY_FILE = 'outputs/answer_key.txt'
SUMMARY_FILE = 'outputs/paper_summary.txt'
FIELDS = ['id','subject','chapter','type','difficulty','marks','question','options','answer']
SUBJECTS = ['Physics','Chemistry','Mathematics']
DIFFICULTIES = ['Easy','Medium','Hard']


def ensure_files():
    os.makedirs('outputs', exist_ok=True)
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w', newline='', encoding='utf-8') as f:
            csv.DictWriter(f, fieldnames=FIELDS).writeheader()


def load_questions():
    ensure_files()
    with open(DATA_FILE, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames:
            reader.fieldnames = [name.strip() for name in reader.fieldnames]
        rows = list(reader)
    if rows and 'id' not in rows[0]:
        raise ValueError('questions.csv is missing the required id column. Check the CSV header row.')
    return rows


def save_questions(rows):
    with open(DATA_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader(); writer.writerows(rows)


def read_used():
    if not os.path.exists(HISTORY_FILE): return set()
    with open(HISTORY_FILE, encoding='utf-8') as f: return set(x.strip() for x in f if x.strip())


def record_used(ids):
    with open(HISTORY_FILE, 'a', encoding='utf-8') as f:
        for qid in ids: f.write(qid+'\n')


def clear_history():
    open(HISTORY_FILE, 'w', encoding='utf-8').close()
    print('Usage history cleared.')


def next_id(rows):
    nums=[]
    for r in rows:
        try: nums.append(int(r['id'].replace('Q','')))
        except ValueError: pass
    return f'Q{max(nums, default=0)+1:03d}'


def add_question(rows, q=None):
    if q is None:
        q={}
        q['subject']=input('Subject (Physics/Chemistry/Mathematics): ').strip()
        q['chapter']=input('Chapter: ').strip()
        q['type']=input('Type (MCQ/Numerical): ').strip()
        q['difficulty']=input('Difficulty (Easy/Medium/Hard): ').strip()
        q['marks']=input('Marks: ').strip()
        q['question']=input('Question text: ').strip()
        q['options']=input('Options (comma-separated, blank for numerical): ').strip()
        q['answer']=input('Correct answer: ').strip()
    if q['subject'] not in SUBJECTS or q['difficulty'] not in DIFFICULTIES or q['type'] not in ['MCQ','Numerical']:
        print('Invalid subject, type or difficulty.'); return rows
    try:
        if float(q['marks']) <= 0: raise ValueError
    except ValueError:
        print('Marks must be a positive number.'); return rows
    if not q['question'] or not q['answer'] or (q['type']=='MCQ' and not q['options']):
        print('Question, answer and MCQ options are required.'); return rows
    q={k:str(q.get(k,'')) for k in FIELDS if k!='id'}
    q['id']=next_id(rows); rows.append(q); save_questions(rows)
    print(f"Question added with ID {q['id']}."); return rows


def view_summary(rows):
    print(f'Question bank: {len(rows)} questions')
    for s in SUBJECTS: print(f'  {s}: {sum(r["subject"]==s for r in rows)}')
    for d in DIFFICULTIES: print(f'  {d}: {sum(r["difficulty"]==d for r in rows)}')


def search_questions(rows):
    criterion=input('Search subject/chapter/difficulty (leave blank to show all): ').strip().lower()
    hits=[r for r in rows if not criterion or criterion in ' '.join(r.values()).lower()]
    print_rows(hits); return hits


def print_rows(rows):
    if not rows: print('No matching questions.'); return
    for r in rows: print(f"{r['id']} | {r['subject']} | {r['chapter']} | {r['difficulty']} | {r['type']} | {r['question']}")


def update_question(rows):
    qid=input('Question ID to update: ').strip().upper()
    for r in rows:
        if r['id']==qid:
            print('Leave a field blank to keep its current value.')
            for field in FIELDS[1:]:
                val=input(f'{field} [{r[field]}]: ').strip()
                if val: r[field]=val
            save_questions(rows); print('Question updated.'); return rows
    print('ID not found.'); return rows


def delete_question(rows):
    qid=input('Question ID to delete: ').strip().upper()
    new=[r for r in rows if r['id']!=qid]
    if len(new)==len(rows): print('ID not found.')
    else: save_questions(new); print('Question deleted.')
    return new


def generate_paper(rows, total=15):
    used=read_used(); eligible=[r for r in rows if r['id'] not in used]
    if len(eligible)<total:
        print(f'Not enough unused questions ({len(eligible)} available, {total} requested).'); return
    # Aim for 1/3 Easy, 1/3 Medium, 1/3 Hard, then fill remaining from unused.
    quotas={'Easy':total//3, 'Medium':total//3, 'Hard':total-total//3*2}
    chosen=[]
    for difficulty, quota in quotas.items():
        pool=[r for r in eligible if r['difficulty']==difficulty and r not in chosen]
        chosen.extend(random.sample(pool, min(quota,len(pool))))
    remaining=[r for r in eligible if r not in chosen]
    if len(chosen)<total: chosen.extend(random.sample(remaining,total-len(chosen)))
    random.shuffle(chosen)
    # Chapter variety is encouraged by selection order: shuffle, then output.
    for r in chosen: r['paper_marks']=float(r['marks'])
    total_marks=sum(float(r['marks']) for r in chosen)
    with open(PAPER_FILE,'w',encoding='utf-8') as f:
        f.write('JEE-STYLE PRACTICE PAPER\nGenerated: '+datetime.now().strftime('%Y-%m-%d %H:%M')+'\n\n')
        for i,r in enumerate(chosen,1):
            f.write(f"{i}. [{r['subject']} | {r['chapter']} | {r['difficulty']} | {r['marks']} marks]\n{r['question']}\n")
            if r['type']=='MCQ': f.write('Options: '+r['options']+'\n')
            f.write('\n')
    with open(KEY_FILE,'w',encoding='utf-8') as f:
        f.write('ANSWER KEY\n\n')
        for i,r in enumerate(chosen,1): f.write(f"{i}. {r['id']} — {r['answer']}\n")
    counts={d:sum(r['difficulty']==d for r in chosen) for d in DIFFICULTIES}
    chapters={}
    for r in chosen: chapters[r['chapter']]=chapters.get(r['chapter'],0)+1
    with open(SUMMARY_FILE,'w',encoding='utf-8') as f:
        f.write(f'PAPER SUMMARY\nQuestions: {len(chosen)}\nTotal marks: {total_marks:g}\n\nDifficulty distribution:\n')
        for d,c in counts.items(): f.write(f'{d}: {c}\n')
        f.write('\nChapter distribution:\n')
        for ch,c in chapters.items(): f.write(f'{ch}: {c}\n')
    record_used([r['id'] for r in chosen])
    print(f'Paper generated: {len(chosen)} questions, {total_marks:g} marks.')
    print(f'Files: {PAPER_FILE}, {KEY_FILE}, {SUMMARY_FILE}')


def main():
    ensure_files(); rows=load_questions()
    menu='''\n=== JEE QUESTION PAPER MANAGEMENT SYSTEM ===\n1. View question-bank summary\n2. Add question\n3. Search questions\n4. Update question\n5. Delete question\n6. Generate practice paper (15 questions)\n7. Clear used-question history\n8. Exit\nChoice: '''
    while True:
        choice=input(menu).strip()
        if choice=='1': view_summary(rows)
        elif choice=='2': rows=add_question(rows)
        elif choice=='3': search_questions(rows)
        elif choice=='4': rows=update_question(rows)
        elif choice=='5': rows=delete_question(rows)
        elif choice=='6': generate_paper(rows,15)
        elif choice=='7': clear_history()
        elif choice=='8': print('Goodbye!'); break
        else: print('Invalid menu choice. Try again.')

if __name__=='__main__': main()

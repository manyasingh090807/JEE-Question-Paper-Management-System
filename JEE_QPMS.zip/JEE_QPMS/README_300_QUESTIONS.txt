JEE Paper Studio complete project package

Contains the complete application, required project files and a 300-question CSV bank (100 Physics, 100 Chemistry, 100 Mathematics).

Extract the folder and run run_app.bat.

CSV loader was updated to handle UTF-8 BOM and whitespace in headers. Backup your existing project before replacing it.

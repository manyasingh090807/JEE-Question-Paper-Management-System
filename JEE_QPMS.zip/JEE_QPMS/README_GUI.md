# JEE Paper Studio — Desktop GUI

A dark-themed Tkinter desktop application for managing the JEE question bank and generating practice papers.

## Run on Windows
1. Extract the ZIP file.
2. Open the `JEE_Project_Final` folder.
3. Double-click `run_app.bat` (or run `python app.py` in a terminal).

## Features
- Dashboard with question-bank and subject statistics
- Question Bank: add, select/update and delete questions
- Generate a 15-question practice paper using the existing engine
- **In-app paper preview popup** with scrollable, exam-style content
- In-app answer-key popup and paper-summary popup
- Save Paper As
- PDF export (optional; requires `pip install reportlab`)
- Print/open via the system print handler
- **Recent Papers** section: saved snapshots of generated papers, keys and summaries can be reopened
- Reset used-question history

## Project files
- `app.py` — GUI, preview windows, recent-paper history, save/export/print
- `jee_qpms.py` — question bank and paper-generation engine
- `questions.csv` — sample question database
- `used_questions.txt` — question-use history
- `outputs/` — latest generated paper, answer key and summary
- `paper_history/` — snapshots of generated papers and associated files
- `docs/` — report and demo images

The paper-generation engine retains its current 15-question selection logic. Preview, history, save, answer-key and summary features are GUI additions.
